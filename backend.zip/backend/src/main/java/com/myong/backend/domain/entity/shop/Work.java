package com.myong.backend.domain.entity.shop;

public enum Work {
    FULLTIME, CONTACT //정규직, 계약직
}
