package com.myong.backend.domain.entity.designer;

public enum Status {
    NO, LATE, WORK, LEAVE, VACATION, REST  //    결근, 지각, 출근, 퇴근, 휴가, 휴직
}
