package com.myong.backend.domain.entity.designer;

public enum Exp {
    NEW, EXP //신입, 경력
}
