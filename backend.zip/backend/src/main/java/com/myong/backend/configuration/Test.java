package com.myong.backend.configuration;

public class Test {
}
