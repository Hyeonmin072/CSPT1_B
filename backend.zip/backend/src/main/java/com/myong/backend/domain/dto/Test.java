package com.myong.backend.domain.dto;

public class Test {
}
