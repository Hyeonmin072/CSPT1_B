package com.myong.backend.domain.entity.business;

public enum ReservationStatus {
    WAIT,CANCEL,SUCCESS; // 대기, 취소, 성공
}
