package com.myong.backend.domain.entity.usershop;

public enum MessageType {
    TEXT,IMAGE,FILE // 텍스트, 이미지, 파일

}
