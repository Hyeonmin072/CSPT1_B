package com.myong.backend.exception;

public class NotEqualVerifyCodeException extends RuntimeException {
    public NotEqualVerifyCodeException(String message) {
        super(message);
    }
}
