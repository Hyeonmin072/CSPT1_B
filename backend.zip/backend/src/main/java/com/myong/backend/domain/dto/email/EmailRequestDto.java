package com.myong.backend.domain.dto.email;

import lombok.Data;

@Data
public class EmailRequestDto {
    private String email;
}
