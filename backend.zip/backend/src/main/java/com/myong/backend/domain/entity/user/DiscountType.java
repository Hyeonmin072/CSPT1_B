package com.myong.backend.domain.entity.user;

public enum DiscountType {
    FIXED, PERCENT // 고정금액 할인, 퍼센트 할인
}
