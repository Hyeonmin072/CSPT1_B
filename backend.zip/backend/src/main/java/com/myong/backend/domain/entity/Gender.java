package com.myong.backend.domain.entity;

import jakarta.persistence.Enumerated;


public enum Gender {
    MALE, FEMALE // 남자, 여자
}
