package com.myong.backend.domain.entity.business;

public enum PayStatus {
    INCOMPLETE,COMPLETE // 미완료, 완료
}
