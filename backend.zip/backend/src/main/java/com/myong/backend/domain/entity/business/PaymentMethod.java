package com.myong.backend.domain.entity.business;

public enum PaymentMethod {
    CASH,CARD; // 현금, 카드
}
